/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shank
 */
import java.sql.*;
import javax.swing.JOptionPane;

public class javaconnect {
    Connection conn=null;
    public static Connection ConnecrDb(){
        try {
            Class.forName("org.sqlite.JDBC");
            //Here I used "bank.db" rather than ".sqlite"
            Connection conn=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\shank\\Documents\\Banking Project\\bank.db");
            return conn;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return null;
    }
}
